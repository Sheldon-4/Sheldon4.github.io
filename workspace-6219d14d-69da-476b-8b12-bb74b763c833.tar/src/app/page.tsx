'use client'

import { useEffect, useState } from 'react';
import { useTestStore } from '@/store/testStore';
import { syllabus, getTotalQuestionCount, getQuestionsBySubject, getQuestionCounts } from '@/lib/questions';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Zap, Target, BookOpen, Clock, FileText, ArrowLeft, 
  ChevronLeft, ChevronRight, CheckCircle, XCircle, 
  AlertCircle, Play, RefreshCw, Home as HomeIcon, Trophy,
  Sparkles, Flame, Star, Rocket, FileStack, Calendar
} from 'lucide-react';

// Floating Particles Component
function FloatingParticles() {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      {/* Animated Blobs */}
      <div className="blob blob-purple w-96 h-96 -top-48 -left-48" style={{ animationDelay: '0s' }} />
      <div className="blob blob-pink w-80 h-80 top-1/3 -right-40" style={{ animationDelay: '2s' }} />
      <div className="blob blob-cyan w-64 h-64 bottom-20 left-1/4" style={{ animationDelay: '4s' }} />
      <div className="blob blob-purple w-72 h-72 -bottom-36 -right-36" style={{ animationDelay: '6s' }} />
      
      {/* Small Particles */}
      {[...Array(20)].map((_, i) => (
        <div
          key={i}
          className="particle"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 8}s`,
            animationDuration: `${8 + Math.random() * 4}s`,
          }}
        />
      ))}
    </div>
  );
}

// Timer Component with 3D effect
function Timer() {
  const { timeRemaining, decrementTime, isTestActive, submitTest } = useTestStore();
  
  useEffect(() => {
    if (!isTestActive || timeRemaining <= 0) return;
    
    const timer = setInterval(() => {
      decrementTime();
    }, 1000);
    
    return () => clearInterval(timer);
  }, [isTestActive, timeRemaining, decrementTime]);

  useEffect(() => {
    if (timeRemaining === 0 && isTestActive) {
      submitTest();
    }
  }, [timeRemaining, isTestActive, submitTest]);
  
  const minutes = Math.floor(timeRemaining / 60);
  const seconds = timeRemaining % 60;
  const isLow = timeRemaining < 300;
  
  return (
    <div className={`glass-card px-6 py-3 flex items-center gap-3 ${isLow ? 'animate-pulse' : ''}`}>
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
        isLow ? 'bg-gradient-to-br from-red-500 to-pink-600' : 'bg-gradient-to-br from-purple-500 to-pink-600'
      }`}>
        <Clock className="w-5 h-5 text-white" />
      </div>
      <div>
        <span className={`font-mono text-2xl font-bold ${isLow ? 'text-red-400' : 'text-white'}`}>
          {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
        </span>
        {isLow && <p className="text-xs text-red-400">Time Low!</p>}
      </div>
    </div>
  );
}

// Home Page Component
function HomePage() {
  const { startFullTest, setView } = useTestStore();
  const questionInfo = getQuestionCounts();
  
  return (
    <div className="min-h-screen gradient-bg-animated grid-pattern relative overflow-hidden">
      <FloatingParticles />
      
      {/* Header */}
      <header className="relative z-50">
        <div className="glass-card mx-4 mt-4 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-500 via-pink-500 to-orange-500 flex items-center justify-center animate-pulse-glow">
                <Sparkles className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gradient">JEE Mains Portal</h1>
                <p className="text-sm text-purple-300 flex items-center gap-2">
                  <Star className="w-3 h-3" /> Complete Exam Prep <Star className="w-3 h-3" />
                </p>
              </div>
            </div>
            <div className="hidden md:flex items-center gap-4">
              <div className="glass-card px-4 py-2 text-sm">
                <span className="text-purple-300">Total Questions:</span>
                <span className="text-white font-bold ml-2">{questionInfo.total.toLocaleString()}+</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12 perspective-container">
          <div className="inline-block animate-float">
            <div className="glass-card px-8 py-10 corner-accent">
              <div className="flex justify-center mb-4">
                <Rocket className="w-14 h-14 text-gradient" />
              </div>
              <h2 className="text-4xl md:text-5xl font-black mb-3">
                <span className="text-gradient">Crack JEE Mains 2025</span>
              </h2>
              <p className="text-lg text-purple-200 max-w-2xl mx-auto leading-relaxed">
                30 Full Test Papers • 75 Questions Each • Previous Year Questions (2019-2024)
              </p>
              <div className="flex justify-center gap-4 mt-4 flex-wrap">
                <Badge className="bg-gradient-to-r from-orange-500 to-red-600 text-white border-0 px-4 py-2">
                  ⚛️ {questionInfo.physics.toLocaleString()}+ Physics
                </Badge>
                <Badge className="bg-gradient-to-r from-green-500 to-emerald-600 text-white border-0 px-4 py-2">
                  🧪 {questionInfo.chemistry.toLocaleString()}+ Chemistry
                </Badge>
                <Badge className="bg-gradient-to-r from-purple-500 to-violet-600 text-white border-0 px-4 py-2">
                  📐 {questionInfo.mathematics.toLocaleString()}+ Mathematics
                </Badge>
              </div>
            </div>
          </div>
        </div>

        {/* Option Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto mb-12">
          {/* Full Test Papers Card */}
          <div 
            className="card-3d cursor-pointer group"
            onClick={() => setView('test-paper-select')}
          >
            <div className="glass-card p-6 h-full neon-glow-purple hover:neon-glow-pink transition-all duration-500">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500 via-violet-500 to-pink-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform animate-bounce-gentle">
                <FileStack className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">30 Test Papers</h3>
              <p className="text-purple-200 text-sm mb-4">Full syllabus tests with 75 questions each! 📚</p>
              <div className="flex flex-wrap gap-2">
                <Badge className="bg-purple-500/20 text-purple-300 border border-purple-500/30 text-xs">
                  30 Papers
                </Badge>
                <Badge className="bg-pink-500/20 text-pink-300 border border-pink-500/30 text-xs">
                  75 Qs each
                </Badge>
              </div>
            </div>
          </div>

          {/* Quick Test Card */}
          <div 
            className="card-3d cursor-pointer group"
            onClick={startFullTest}
          >
            <div className="glass-card p-6 h-full neon-glow-orange hover:neon-glow-pink transition-all duration-500">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-500 via-red-500 to-pink-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform animate-bounce-gentle" style={{ animationDelay: '0.1s' }}>
                <Zap className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Quick Test</h3>
              <p className="text-purple-200 text-sm mb-4">Fast 15-question test across all subjects! ⚡</p>
              <div className="flex flex-wrap gap-2">
                <Badge className="bg-orange-500/20 text-orange-300 border border-orange-500/30 text-xs">
                  15 Questions
                </Badge>
                <Badge className="bg-red-500/20 text-red-300 border border-red-500/30 text-xs">
                  60 min
                </Badge>
              </div>
            </div>
          </div>

          {/* Topic-wise Test Card */}
          <div 
            className="card-3d cursor-pointer group"
            onClick={() => setView('topic-select')}
          >
            <div className="glass-card p-6 h-full neon-glow-green hover:neon-glow-cyan transition-all duration-500">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-green-500 via-emerald-500 to-cyan-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform animate-bounce-gentle" style={{ animationDelay: '0.2s' }}>
                <Target className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Topic-wise</h3>
              <p className="text-purple-200 text-sm mb-4">Practice specific chapters! 🎯</p>
              <div className="flex flex-wrap gap-2">
                <Badge className="bg-green-500/20 text-green-300 border border-green-500/30 text-xs">
                  82 Topics
                </Badge>
                <Badge className="bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-xs">
                  Focus Mode
                </Badge>
              </div>
            </div>
          </div>

          {/* View Syllabus Card */}
          <div 
            className="card-3d cursor-pointer group"
            onClick={() => setView('syllabus')}
          >
            <div className="glass-card p-6 h-full neon-glow-cyan hover:neon-glow-purple transition-all duration-500">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500 via-blue-500 to-violet-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform animate-bounce-gentle" style={{ animationDelay: '0.3s' }}>
                <BookOpen className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Syllabus</h3>
              <p className="text-purple-200 text-sm mb-4">Complete JEE syllabus overview! 📖</p>
              <div className="flex flex-wrap gap-2">
                <Badge className="bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-xs">
                  3 Subjects
                </Badge>
                <Badge className="bg-blue-500/20 text-blue-300 border border-blue-500/30 text-xs">
                  82 Chapters
                </Badge>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="max-w-5xl mx-auto">
          <div className="glass-card p-6">
            <h3 className="text-xl font-bold text-white mb-6 text-center flex items-center justify-center gap-2">
              <Flame className="w-5 h-5 text-orange-400" /> Question Bank Stats <Flame className="w-5 h-5 text-orange-400" />
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div className="text-center group">
                <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center text-3xl mb-2 group-hover:scale-110 transition-transform neon-glow-orange">
                  ⚛️
                </div>
                <p className="font-bold text-white">{questionInfo.physics.toLocaleString()}+</p>
                <p className="text-purple-300 text-sm">Physics</p>
              </div>
              <div className="text-center group">
                <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center text-3xl mb-2 group-hover:scale-110 transition-transform neon-glow-green">
                  🧪
                </div>
                <p className="font-bold text-white">{questionInfo.chemistry.toLocaleString()}+</p>
                <p className="text-purple-300 text-sm">Chemistry</p>
              </div>
              <div className="text-center group">
                <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center text-3xl mb-2 group-hover:scale-110 transition-transform neon-glow-purple">
                  📐
                </div>
                <p className="font-bold text-white">{questionInfo.mathematics.toLocaleString()}+</p>
                <p className="text-purple-300 text-sm">Mathematics</p>
              </div>
              <div className="text-center group">
                <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-pink-500 to-rose-600 flex items-center justify-center text-3xl mb-2 group-hover:scale-110 transition-transform neon-glow-pink">
                  📝
                </div>
                <p className="font-bold text-gradient">{questionInfo.total.toLocaleString()}+</p>
                <p className="text-purple-300 text-sm">Total Qs</p>
              </div>
              <div className="text-center group">
                <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-yellow-500 to-orange-600 flex items-center justify-center text-3xl mb-2 group-hover:scale-110 transition-transform">
                  🏆
                </div>
                <p className="font-bold text-white">{questionInfo.previousYear}+</p>
                <p className="text-purple-300 text-sm">Prev. Year</p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

// Test Paper Selection Page
function TestPaperSelectPage() {
  const { startTestPaper, setView, getAvailablePapers } = useTestStore();
  const papers = getAvailablePapers();
  
  return (
    <div className="min-h-screen gradient-bg-animated grid-pattern relative overflow-hidden">
      <FloatingParticles />
      
      {/* Header */}
      <header className="relative z-50">
        <div className="glass-card mx-4 mt-4 px-6 py-4">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setView('home')}
              className="glass-card hover:bg-white/10 text-white"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center">
              <FileStack className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gradient">30 Full Test Papers</h1>
              <p className="text-sm text-purple-300">75 Questions Each • 25 per Subject</p>
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Info Card */}
          <div className="glass-card p-6 mb-8 text-center">
            <h2 className="text-2xl font-bold text-gradient mb-2">Complete JEE Mains Simulation</h2>
            <p className="text-purple-200">Each paper contains 25 Physics + 25 Chemistry + 25 Mathematics questions</p>
            <div className="flex justify-center gap-4 mt-4 flex-wrap">
              <Badge className="bg-orange-500/20 text-orange-300 border border-orange-500/30 px-4 py-2">
                ⏱️ 90 Minutes Each
              </Badge>
              <Badge className="bg-green-500/20 text-green-300 border border-green-500/30 px-4 py-2">
                📊 Mixed Difficulty
              </Badge>
              <Badge className="bg-purple-500/20 text-purple-300 border border-purple-500/30 px-4 py-2">
                🎯 Previous Year Questions
              </Badge>
            </div>
          </div>

          {/* Paper Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-6 gap-4">
            {papers.map((paper) => (
              <div 
                key={paper}
                className="card-3d cursor-pointer group"
                onClick={() => startTestPaper(paper)}
              >
                <div className="glass-card p-6 text-center hover:neon-glow-purple transition-all duration-300">
                  <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                    <span className="text-white text-xl font-bold">{paper}</span>
                  </div>
                  <p className="text-white font-semibold">Paper {paper}</p>
                  <p className="text-purple-300 text-xs mt-1">75 Questions</p>
                  <Button 
                    size="sm" 
                    className="mt-3 w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white"
                  >
                    <Play className="w-3 h-3 mr-1" /> Start
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}

// Topic Selection Page
function TopicSelectPage() {
  const { selectedSubject, selectSubject, selectedTopic, startTopicTest, setView, getTopicQuestionCount } = useTestStore();
  const [searchTerm, setSearchTerm] = useState('');
  
  const subjects = ['physics', 'chemistry', 'mathematics'] as const;
  
  const getTopicsForSubject = (subject: typeof subjects[number]) => {
    const subjectQuestions = getQuestionsBySubject(subject);
    const topics = [...new Set(subjectQuestions.map(q => q.topic))];
    if (searchTerm) {
      return topics.filter(t => t.toLowerCase().includes(searchTerm.toLowerCase()));
    }
    return topics;
  };

  const handleStartTest = () => {
    if (selectedSubject && selectedTopic) {
      startTopicTest(selectedSubject, selectedTopic);
    }
  };
  
  return (
    <div className="min-h-screen gradient-bg-animated grid-pattern relative overflow-hidden">
      <FloatingParticles />
      
      {/* Header */}
      <header className="relative z-50">
        <div className="glass-card mx-4 mt-4 px-6 py-4">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setView('home')}
              className="glass-card hover:bg-white/10 text-white"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-500 to-cyan-600 flex items-center justify-center">
              <Target className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gradient">Topic-wise Test</h1>
              <p className="text-sm text-purple-300">Pick your topic & start practicing!</p>
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 container mx-auto px-4 py-8">
        <div className="max-w-5xl mx-auto">
          {/* Search Bar */}
          <div className="glass-card p-4 mb-6">
            <input
              type="text"
              placeholder="🔍 Search topics..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-purple-300 focus:outline-none focus:border-purple-500 transition-colors"
            />
          </div>

          <Tabs value={selectedSubject || 'physics'} onValueChange={(v) => selectSubject(v as typeof subjects[number])} className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-8 glass-card p-2">
              <TabsTrigger 
                value="physics" 
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-600 data-[state=active]:text-white text-purple-300 rounded-xl py-3"
              >
                <span className="text-xl mr-2">⚛️</span> Physics
              </TabsTrigger>
              <TabsTrigger 
                value="chemistry"
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-500 data-[state=active]:to-emerald-600 data-[state=active]:text-white text-purple-300 rounded-xl py-3"
              >
                <span className="text-xl mr-2">🧪</span> Chemistry
              </TabsTrigger>
              <TabsTrigger 
                value="mathematics"
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-violet-600 data-[state=active]:text-white text-purple-300 rounded-xl py-3"
              >
                <span className="text-xl mr-2">📐</span> Mathematics
              </TabsTrigger>
            </TabsList>

            {subjects.map((subject) => (
              <TabsContent key={subject} value={subject}>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {getTopicsForSubject(subject).map((topic, index) => (
                    <div 
                      key={topic}
                      className={`card-3d cursor-pointer ${selectedTopic === topic ? 'pointer-events-none' : ''}`}
                      onClick={() => {
                        useTestStore.setState({ selectedTopic: topic, selectedSubject: subject });
                      }}
                    >
                      <div className={`glass-card p-5 h-full transition-all duration-300 ${
                        selectedTopic === topic 
                          ? 'border-2 border-green-400 neon-glow-green' 
                          : 'hover:border-purple-400/50'
                      }`}>
                        <div className="flex items-start gap-4">
                          <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold flex-shrink-0 ${
                            selectedTopic === topic
                              ? 'bg-gradient-to-br from-green-500 to-emerald-600'
                              : 'bg-gradient-to-br from-purple-500/50 to-pink-500/50'
                          }`}>
                            {selectedTopic === topic ? (
                              <CheckCircle className="w-6 h-6" />
                            ) : (
                              index + 1
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <h4 className="font-semibold text-white truncate">{topic}</h4>
                            <p className="text-sm text-purple-300 mt-1">
                              {getTopicQuestionCount(subject, topic)} questions
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>

          {selectedTopic && (
            <div className="mt-8 flex justify-center">
              <Button 
                size="lg" 
                className="btn-3d gap-3 bg-gradient-to-r from-green-500 via-emerald-500 to-cyan-600 hover:from-green-600 hover:via-emerald-600 hover:to-cyan-700 text-white text-lg px-10 py-6 rounded-2xl neon-glow-green"
                onClick={handleStartTest}
              >
                <Play className="w-6 h-6" />
                Start Test: {selectedTopic}
                <Rocket className="w-5 h-5" />
              </Button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

// Test Page Component
function TestPage() {
  const { 
    questions, 
    currentQuestionIndex, 
    answers, 
    answerQuestion, 
    nextQuestion, 
    previousQuestion,
    submitTest,
    setView,
    testType,
    selectedPaperNumber
  } = useTestStore();
  
  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;
  
  if (!currentQuestion) {
    return <div className="min-h-screen gradient-bg-animated flex items-center justify-center">
      <div className="glass-card p-8 text-center">
        <div className="animate-spin-slow w-16 h-16 mx-auto rounded-full border-4 border-purple-500 border-t-transparent mb-4"></div>
        <p className="text-white text-lg">Loading questions...</p>
      </div>
    </div>;
  }

  const isAnswered = answers[currentQuestion.id] !== undefined;
  const testTitle = testType === 'paper' ? `Paper ${selectedPaperNumber}` : testType === 'full' ? 'Full Test' : 'Topic Test';
  
  return (
    <div className="min-h-screen gradient-bg-animated grid-pattern relative overflow-hidden flex flex-col">
      <FloatingParticles />
      
      {/* Header */}
      <header className="relative z-50">
        <div className="glass-card mx-4 mt-4 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setView('home')}
                className="glass-card hover:bg-white/10 text-white"
              >
                <HomeIcon className="w-5 h-5" />
              </Button>
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center">
                <FileText className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">{testTitle}</h1>
                <p className="text-sm text-purple-300">
                  Question {currentQuestionIndex + 1} of {questions.length}
                  {currentQuestion.year && <span className="ml-2 text-yellow-400">(JEE {currentQuestion.year})</span>}
                </p>
              </div>
            </div>
            <Timer />
          </div>
        </div>
      </header>

      {/* Progress Bar */}
      <div className="relative mx-4 mt-4 z-40">
        <div className="h-2 bg-white/10 rounded-full overflow-hidden glass-card p-0">
          <div 
            className="h-full bg-gradient-to-r from-purple-500 via-pink-500 to-orange-500 transition-all duration-500 rounded-full progress-glow"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="flex justify-between mt-2 text-sm text-purple-300">
          <span>{Math.round(progress)}% Complete</span>
          <span>{questions.length - currentQuestionIndex - 1} remaining</span>
        </div>
      </div>

      <main className="relative z-10 flex-1 container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Question Card */}
          <div className="glass-card p-8 mb-8 corner-accent">
            <div className="flex flex-wrap items-center gap-3 mb-6">
              <Badge className="bg-gradient-to-r from-purple-500 to-pink-600 text-white border-0 px-4 py-1">
                {currentQuestion.subject}
              </Badge>
              <Badge className="bg-white/10 text-purple-200 border border-white/20 px-4 py-1">
                {currentQuestion.topic}
              </Badge>
              <Badge className={`px-4 py-1 ${
                currentQuestion.difficulty === 'easy' ? 'bg-green-500/20 text-green-300 border-green-500/30' : 
                currentQuestion.difficulty === 'medium' ? 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30' : 
                'bg-red-500/20 text-red-300 border-red-500/30'
              } border`}>
                {currentQuestion.difficulty.toUpperCase()}
              </Badge>
              {currentQuestion.year && (
                <Badge className="bg-yellow-500/20 text-yellow-300 border border-yellow-500/30 px-4 py-1">
                  <Calendar className="w-3 h-3 mr-1" /> JEE {currentQuestion.year}
                </Badge>
              )}
            </div>
            
            <h2 className="text-xl md:text-2xl font-semibold text-white leading-relaxed mb-8">
              <span className="text-gradient font-bold">Q{currentQuestionIndex + 1}.</span> {currentQuestion.question}
            </h2>
            
            <div className="space-y-4">
              {currentQuestion.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => answerQuestion(currentQuestion.id, index)}
                  className={`option-btn w-full text-left p-5 rounded-2xl border-2 transition-all duration-300 ${
                    answers[currentQuestion.id] === index
                      ? 'border-purple-500 bg-purple-500/20 neon-glow-purple'
                      : 'border-white/10 bg-white/5 hover:border-purple-500/50 hover:bg-white/10'
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-lg font-bold transition-all ${
                      answers[currentQuestion.id] === index
                        ? 'bg-gradient-to-br from-purple-500 to-pink-600 text-white'
                        : 'bg-white/10 text-purple-300'
                    }`}>
                      {String.fromCharCode(65 + index)}
                    </div>
                    <span className="text-white text-lg">{option}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Question Navigation */}
          <div className="glass-card p-6 mb-8">
            <p className="text-sm text-purple-300 mb-4 flex items-center gap-2">
              <Target className="w-4 h-4" /> Jump to question:
            </p>
            <ScrollArea className="w-full">
              <div className="flex gap-2 pb-2">
                {questions.map((q, index) => (
                  <button
                    key={q.id}
                    onClick={() => useTestStore.setState({ currentQuestionIndex: index })}
                    className={`question-num-btn w-12 h-12 rounded-xl font-bold transition-all duration-300 flex-shrink-0 ${
                      index === currentQuestionIndex
                        ? 'bg-gradient-to-br from-purple-500 to-pink-600 text-white neon-glow-purple'
                        : answers[q.id] !== undefined
                        ? 'bg-gradient-to-br from-green-500/30 to-emerald-500/30 text-green-300 border border-green-500/30'
                        : 'bg-white/5 text-purple-300 border border-white/10 hover:border-purple-500/50'
                    }`}
                  >
                    {index + 1}
                  </button>
                ))}
              </div>
            </ScrollArea>
          </div>

          {/* Navigation Buttons */}
          <div className="flex items-center justify-between gap-4">
            <Button
              variant="outline"
              onClick={previousQuestion}
              disabled={currentQuestionIndex === 0}
              className="glass-card border-white/20 text-white hover:bg-white/10 px-6 py-6 rounded-xl disabled:opacity-50"
            >
              <ChevronLeft className="w-5 h-5 mr-2" />
              Previous
            </Button>
            
            <div className="flex gap-4">
              {currentQuestionIndex === questions.length - 1 ? (
                <Button
                  onClick={submitTest}
                  className="btn-3d gap-2 bg-gradient-to-r from-green-500 via-emerald-500 to-cyan-600 hover:from-green-600 hover:via-emerald-600 hover:to-cyan-700 text-white px-8 py-6 rounded-xl neon-glow-green"
                >
                  <Trophy className="w-5 h-5" />
                  Submit Test
                </Button>
              ) : (
                <Button
                  onClick={nextQuestion}
                  className="btn-3d gap-2 bg-gradient-to-r from-purple-500 via-pink-500 to-orange-500 hover:from-purple-600 hover:via-pink-600 hover:to-orange-600 text-white px-8 py-6 rounded-xl neon-glow-purple"
                >
                  Next
                  <ChevronRight className="w-5 h-5" />
                </Button>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

// Syllabus Page Component
function SyllabusPage() {
  const { setView } = useTestStore();
  
  return (
    <div className="min-h-screen gradient-bg-animated grid-pattern relative overflow-hidden">
      <FloatingParticles />
      
      {/* Header */}
      <header className="relative z-50">
        <div className="glass-card mx-4 mt-4 px-6 py-4">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setView('home')}
              className="glass-card hover:bg-white/10 text-white"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gradient">JEE Mains Syllabus</h1>
              <p className="text-sm text-purple-300">Complete syllabus for all subjects</p>
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8">
            {/* Physics */}
            <div className="card-3d">
              <div className="glass-card p-6 h-full neon-glow-orange">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center text-3xl">
                    ⚛️
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white">Physics</h3>
                    <p className="text-purple-300">{syllabus.physics.chapters.length} Chapters</p>
                  </div>
                </div>
                <ScrollArea className="h-80">
                  <ul className="space-y-3">
                    {syllabus.physics.chapters.map((chapter, index) => (
                      <li key={index} className="flex items-start gap-3 text-sm group">
                        <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-orange-500/20 to-red-500/20 flex items-center justify-center text-orange-400 font-bold flex-shrink-0 group-hover:from-orange-500 group-hover:to-red-500 group-hover:text-white transition-all">
                          {index + 1}
                        </span>
                        <span className="text-purple-100 pt-1">{chapter}</span>
                      </li>
                    ))}
                  </ul>
                </ScrollArea>
              </div>
            </div>

            {/* Chemistry */}
            <div className="card-3d">
              <div className="glass-card p-6 h-full neon-glow-green">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center text-3xl">
                    🧪
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white">Chemistry</h3>
                    <p className="text-purple-300">{syllabus.chemistry.chapters.length} Chapters</p>
                  </div>
                </div>
                <ScrollArea className="h-80">
                  <ul className="space-y-3">
                    {syllabus.chemistry.chapters.map((chapter, index) => (
                      <li key={index} className="flex items-start gap-3 text-sm group">
                        <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-green-500/20 to-emerald-500/20 flex items-center justify-center text-green-400 font-bold flex-shrink-0 group-hover:from-green-500 group-hover:to-emerald-500 group-hover:text-white transition-all">
                          {index + 1}
                        </span>
                        <span className="text-purple-100 pt-1">{chapter}</span>
                      </li>
                    ))}
                  </ul>
                </ScrollArea>
              </div>
            </div>

            {/* Mathematics */}
            <div className="card-3d">
              <div className="glass-card p-6 h-full neon-glow-purple">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center text-3xl">
                    📐
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white">Mathematics</h3>
                    <p className="text-purple-300">{syllabus.mathematics.chapters.length} Chapters</p>
                  </div>
                </div>
                <ScrollArea className="h-80">
                  <ul className="space-y-3">
                    {syllabus.mathematics.chapters.map((chapter, index) => (
                      <li key={index} className="flex items-start gap-3 text-sm group">
                        <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500/20 to-violet-500/20 flex items-center justify-center text-purple-400 font-bold flex-shrink-0 group-hover:from-purple-500 group-hover:to-violet-500 group-hover:text-white transition-all">
                          {index + 1}
                        </span>
                        <span className="text-purple-100 pt-1">{chapter}</span>
                      </li>
                    ))}
                  </ul>
                </ScrollArea>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

// Results Page Component
function ResultsPage() {
  const { questions, answers, getScore, resetTest, setView, testType, selectedPaperNumber } = useTestStore();
  const score = getScore();
  
  const getGradeColor = (percentage: number) => {
    if (percentage >= 80) return 'from-green-500 to-emerald-600';
    if (percentage >= 60) return 'from-yellow-500 to-orange-600';
    if (percentage >= 40) return 'from-orange-500 to-red-600';
    return 'from-red-500 to-pink-600';
  };

  const getGrade = (percentage: number) => {
    if (percentage >= 80) return '🎉 Excellent!';
    if (percentage >= 60) return '👍 Good Job!';
    if (percentage >= 40) return '💪 Keep Practicing!';
    return '📚 Need Improvement';
  };

  const getEmoji = (percentage: number) => {
    if (percentage >= 80) return '🏆';
    if (percentage >= 60) return '⭐';
    if (percentage >= 40) return '🎯';
    return '📚';
  };

  const testTitle = testType === 'paper' ? `Paper ${selectedPaperNumber}` : testType === 'full' ? 'Full Test' : 'Topic Test';
  
  return (
    <div className="min-h-screen gradient-bg-animated grid-pattern relative overflow-hidden">
      <FloatingParticles />
      
      {/* Header */}
      <header className="relative z-50">
        <div className="glass-card mx-4 mt-4 px-6 py-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-500 via-pink-500 to-orange-500 flex items-center justify-center animate-pulse-glow">
              <Trophy className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gradient">{testTitle} - Results</h1>
              <p className="text-sm text-purple-300">Review your performance</p>
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Score Card */}
          <div className="glass-card p-8 mb-8 text-center corner-accent">
            <div className="mb-6">
              <div className="score-circle w-40 h-40 mx-auto rounded-full flex items-center justify-center">
                <div className="text-6xl">{getEmoji(score.percentage)}</div>
              </div>
            </div>
            
            <h2 className="text-3xl font-bold mb-2 text-gradient">{getGrade(score.percentage)}</h2>
            
            <div className={`text-8xl font-black mb-4 bg-gradient-to-r ${getGradeColor(score.percentage)} bg-clip-text text-transparent`}>
              {score.percentage}%
            </div>
            
            <p className="text-xl text-purple-200 mb-8">
              You scored <span className="text-white font-bold">{score.correct}</span> out of <span className="text-white font-bold">{score.total}</span> questions correctly!
            </p>
            
            <div className="grid grid-cols-3 gap-6 max-w-md mx-auto">
              <div className="glass-card p-6 rounded-2xl neon-glow-green">
                <div className="text-4xl font-black text-green-400">{score.correct}</div>
                <div className="text-sm text-green-300 mt-1">Correct ✓</div>
              </div>
              <div className="glass-card p-6 rounded-2xl neon-glow-pink">
                <div className="text-4xl font-black text-red-400">{score.wrong}</div>
                <div className="text-sm text-red-300 mt-1">Wrong ✗</div>
              </div>
              <div className="glass-card p-6 rounded-2xl">
                <div className="text-4xl font-black text-purple-400">{score.skipped}</div>
                <div className="text-sm text-purple-300 mt-1">Skipped ○</div>
              </div>
            </div>
          </div>

          {/* Detailed Results */}
          <div className="glass-card p-8 mb-8">
            <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <FileText className="w-5 h-5 text-purple-400" /> Detailed Review
            </h3>
            <ScrollArea className="h-96">
              <div className="space-y-4">
                {questions.map((q, index) => {
                  const userAnswer = answers[q.id];
                  const isCorrect = userAnswer === q.correctAnswer;
                  const isSkipped = userAnswer === undefined;
                  
                  return (
                    <div 
                      key={q.id}
                      className={`glass-card p-6 ${
                        isSkipped 
                          ? 'border-l-4 border-l-purple-500' 
                          : isCorrect 
                          ? 'border-l-4 border-l-green-500' 
                          : 'border-l-4 border-l-red-500'
                      }`}
                    >
                      <div className="flex items-start gap-4">
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${
                          isSkipped 
                            ? 'bg-purple-500/20 text-purple-300' 
                            : isCorrect 
                            ? 'bg-green-500/20 text-green-400' 
                            : 'bg-red-500/20 text-red-400'
                        }`}>
                          {isSkipped ? (
                            <AlertCircle className="w-6 h-6" />
                          ) : isCorrect ? (
                            <CheckCircle className="w-6 h-6" />
                          ) : (
                            <XCircle className="w-6 h-6" />
                          )}
                        </div>
                        <div className="flex-1">
                          <p className="font-semibold text-white mb-4 text-lg">
                            {index + 1}. {q.question}
                            {q.year && <span className="ml-2 text-yellow-400 text-sm">(JEE {q.year})</span>}
                          </p>
                          <div className="space-y-2">
                            {q.options.map((option, optIndex) => (
                              <div 
                                key={optIndex}
                                className={`flex items-center gap-3 p-3 rounded-lg ${
                                  optIndex === q.correctAnswer
                                    ? 'bg-green-500/20 text-green-300'
                                    : optIndex === userAnswer && optIndex !== q.correctAnswer
                                    ? 'bg-red-500/20 text-red-300'
                                    : 'text-purple-300'
                                }`}
                              >
                                <span className="font-bold w-8">{String.fromCharCode(65 + optIndex)}.</span>
                                <span className="flex-1">{option}</span>
                                {optIndex === q.correctAnswer && (
                                  <Badge className="bg-green-500/30 text-green-300 border border-green-500/50 text-xs">
                                    ✓ Correct
                                  </Badge>
                                )}
                                {optIndex === userAnswer && optIndex !== q.correctAnswer && (
                                  <Badge className="bg-red-500/30 text-red-300 border border-red-500/50 text-xs">
                                    ✗ Your Answer
                                  </Badge>
                                )}
                              </div>
                            ))}
                          </div>
                          {/* Quick Explanation */}
                          <div className="mt-4 p-4 rounded-xl bg-white/5 text-purple-200 text-sm">
                            <strong className="text-purple-100">💡 Quick Explanation:</strong> {q.explanation}
                          </div>
                          
                          {/* Detailed Solution - Expandable */}
                          <details className="mt-3 group">
                            <summary className="cursor-pointer text-cyan-400 hover:text-cyan-300 text-sm flex items-center gap-2 p-3 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 transition-colors">
                              <span className="group-open:hidden">📖 Show Detailed Solution</span>
                              <span className="hidden group-open:inline">📖 Hide Detailed Solution</span>
                            </summary>
                            <div className="mt-3 p-5 rounded-xl bg-gradient-to-br from-cyan-500/10 via-purple-500/10 to-pink-500/10 border border-cyan-500/20">
                              <div className="text-cyan-300 font-semibold mb-3 flex items-center gap-2">
                                <span className="w-6 h-6 rounded-lg bg-cyan-500/20 flex items-center justify-center text-sm">📝</span>
                                Step-by-Step Solution:
                              </div>
                              <div className="text-purple-100 text-sm whitespace-pre-line leading-relaxed">
                                {q.detailedSolution || q.explanation}
                              </div>
                              {q.concepts && q.concepts.length > 0 && (
                                <div className="mt-4 pt-4 border-t border-cyan-500/20">
                                  <p className="text-cyan-300 text-xs mb-2">📌 Key Concepts:</p>
                                  <div className="flex flex-wrap gap-2">
                                    {q.concepts.map((concept, ci) => (
                                      <Badge key={ci} className="bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-xs">
                                        {concept}
                                      </Badge>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          </details>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </ScrollArea>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-center gap-6">
            <Button
              variant="outline"
              onClick={() => setView('home')}
              className="glass-card border-white/20 text-white hover:bg-white/10 px-8 py-6 rounded-xl text-lg"
            >
              <HomeIcon className="w-5 h-5 mr-2" />
              Back to Home
            </Button>
            <Button
              onClick={resetTest}
              className="btn-3d gap-2 bg-gradient-to-r from-purple-500 via-pink-500 to-orange-500 hover:from-purple-600 hover:via-pink-600 hover:to-orange-600 text-white px-8 py-6 rounded-xl text-lg neon-glow-purple"
            >
              <RefreshCw className="w-5 h-5" />
              Try Another Test
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}

// Main App Component
export default function Home() {
  const currentView = useTestStore((state) => state.currentView);
  
  switch (currentView) {
    case 'home':
      return <HomePage />;
    case 'full-test':
    case 'topic-test':
      return <TestPage />;
    case 'test-paper-select':
      return <TestPaperSelectPage />;
    case 'topic-select':
      return <TopicSelectPage />;
    case 'syllabus':
      return <SyllabusPage />;
    case 'results':
      return <ResultsPage />;
    default:
      return <HomePage />;
  }
}
