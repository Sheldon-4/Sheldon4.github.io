import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "JEE Mains Test Portal - Practice Makes Perfect",
  description: "Prepare for JEE Mains with our comprehensive test platform. Take full-length tests or practice specific topics in Physics, Chemistry, and Mathematics.",
  keywords: ["JEE Mains", "JEE Practice", "Physics", "Chemistry", "Mathematics", "Engineering Entrance", "Test Portal"],
  authors: [{ name: "JEE Portal Team" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "JEE Mains Test Portal",
    description: "Comprehensive JEE Mains practice platform with tests and syllabus",
    url: "https://jee-portal.ai",
    siteName: "JEE Mains Portal",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "JEE Mains Test Portal",
    description: "Comprehensive JEE Mains practice platform with tests and syllabus",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
