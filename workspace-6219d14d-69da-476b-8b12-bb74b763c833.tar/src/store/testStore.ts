import { create } from 'zustand';
import { 
  Question, 
  getQuestionsBySubject, 
  getQuestionsByTopic, 
  getFullTestPaper,
  getAvailableTestPapers,
  getTotalQuestionCount,
  getQuestionCounts,
  allQuestions
} from '@/lib/questions';

export type View = 'home' | 'full-test' | 'topic-select' | 'topic-test' | 'syllabus' | 'results' | 'test-paper-select';

interface TestState {
  currentView: View;
  questions: Question[];
  currentQuestionIndex: number;
  answers: Record<string, number>;
  timeRemaining: number;
  isTestActive: boolean;
  selectedSubject: 'physics' | 'chemistry' | 'mathematics' | null;
  selectedTopic: string | null;
  testType: 'full' | 'topic' | 'paper' | null;
  selectedPaperNumber: number | null;
  totalQuestionsInBank: number;
  
  // Actions
  setView: (view: View) => void;
  startFullTest: () => void;
  startTestPaper: (paperNumber: number) => void;
  startTopicTest: (subject: 'physics' | 'chemistry' | 'mathematics', topic: string) => void;
  selectSubject: (subject: 'physics' | 'chemistry' | 'mathematics') => void;
  selectTopic: (topic: string) => void;
  answerQuestion: (questionId: string, answerIndex: number) => void;
  nextQuestion: () => void;
  previousQuestion: () => void;
  submitTest: () => void;
  resetTest: () => void;
  decrementTime: () => void;
  getScore: () => { correct: number; wrong: number; skipped: number; total: number; percentage: number };
  getTopicQuestionCount: (subject: 'physics' | 'chemistry' | 'mathematics', topic: string) => number;
  getAvailablePapers: () => number[];
  getQuestionCountInfo: () => ReturnType<typeof getQuestionCounts>;
}

const FULL_TEST_TIME = 60 * 60; // 60 minutes for full test (scaled for demo)
const PAPER_TEST_TIME = 90 * 60; // 90 minutes for full paper test (75 questions)
const TOPIC_TEST_TIME = 15 * 60; // 15 minutes for topic test
const QUESTIONS_PER_FULL_TEST = 15; // Quick full test
const QUESTIONS_PER_TOPIC_TEST = 15; // Questions per topic test

// Helper function to shuffle array
function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

// Get balanced questions across subjects
function getBalancedQuestions(count: number): Question[] {
  const perSubject = Math.floor(count / 3);
  const physics = shuffleArray(getQuestionsBySubject('physics')).slice(0, perSubject);
  const chemistry = shuffleArray(getQuestionsBySubject('chemistry')).slice(0, perSubject);
  const mathematics = shuffleArray(getQuestionsBySubject('mathematics')).slice(0, perSubject);
  
  const remaining = count - (perSubject * 3);
  const extraPhysics = shuffleArray(getQuestionsBySubject('physics').filter(q => !physics.includes(q))).slice(0, remaining);
  
  return shuffleArray([...physics, ...chemistry, ...mathematics, ...extraPhysics]);
}

export const useTestStore = create<TestState>((set, get) => ({
  currentView: 'home',
  questions: [],
  currentQuestionIndex: 0,
  answers: {},
  timeRemaining: FULL_TEST_TIME,
  isTestActive: false,
  selectedSubject: null,
  selectedTopic: null,
  testType: null,
  selectedPaperNumber: null,
  totalQuestionsInBank: getTotalQuestionCount(),

  setView: (view) => set({ currentView: view }),

  startFullTest: () => {
    const allQuestions = getBalancedQuestions(QUESTIONS_PER_FULL_TEST);
    set({
      currentView: 'full-test',
      questions: allQuestions,
      currentQuestionIndex: 0,
      answers: {},
      timeRemaining: FULL_TEST_TIME,
      isTestActive: true,
      testType: 'full',
      selectedPaperNumber: null
    });
  },

  startTestPaper: (paperNumber: number) => {
    const paperQuestions = getFullTestPaper(paperNumber);
    set({
      currentView: 'full-test',
      questions: paperQuestions,
      currentQuestionIndex: 0,
      answers: {},
      timeRemaining: PAPER_TEST_TIME,
      isTestActive: true,
      testType: 'paper',
      selectedPaperNumber: paperNumber
    });
  },

  startTopicTest: (subject, topic) => {
    const topicQuestions = getQuestionsByTopic(subject, topic);
    // Shuffle and limit questions for topic test
    const shuffledQuestions = shuffleArray(topicQuestions).slice(0, QUESTIONS_PER_TOPIC_TEST);
    
    // If not enough questions for topic, get more from subject
    const finalQuestions = shuffledQuestions.length >= 5 
      ? shuffledQuestions 
      : shuffleArray(getQuestionsBySubject(subject)).slice(0, QUESTIONS_PER_TOPIC_TEST);
    
    set({
      currentView: 'topic-test',
      questions: finalQuestions,
      currentQuestionIndex: 0,
      answers: {},
      timeRemaining: TOPIC_TEST_TIME,
      isTestActive: true,
      selectedSubject: subject,
      selectedTopic: topic,
      testType: 'topic',
      selectedPaperNumber: null
    });
  },

  selectSubject: (subject) => set({ selectedSubject: subject, selectedTopic: null }),
  
  selectTopic: (topic) => set({ selectedTopic: topic }),

  answerQuestion: (questionId, answerIndex) => {
    set((state) => ({
      answers: { ...state.answers, [questionId]: answerIndex }
    }));
  },

  nextQuestion: () => {
    set((state) => ({
      currentQuestionIndex: Math.min(state.currentQuestionIndex + 1, state.questions.length - 1)
    }));
  },

  previousQuestion: () => {
    set((state) => ({
      currentQuestionIndex: Math.max(state.currentQuestionIndex - 1, 0)
    }));
  },

  submitTest: () => {
    set((state) => ({
      currentView: 'results',
      isTestActive: false
    }));
  },

  resetTest: () => {
    set({
      currentView: 'home',
      questions: [],
      currentQuestionIndex: 0,
      answers: {},
      timeRemaining: FULL_TEST_TIME,
      isTestActive: false,
      selectedSubject: null,
      selectedTopic: null,
      testType: null,
      selectedPaperNumber: null
    });
  },

  decrementTime: () => {
    set((state) => {
      if (state.timeRemaining <= 0) {
        return { timeRemaining: 0, isTestActive: false };
      }
      return { timeRemaining: state.timeRemaining - 1 };
    });
  },

  getScore: () => {
    const state = get();
    let correct = 0;
    let wrong = 0;
    let skipped = 0;

    state.questions.forEach((q) => {
      if (state.answers[q.id] === undefined) {
        skipped++;
      } else if (state.answers[q.id] === q.correctAnswer) {
        correct++;
      } else {
        wrong++;
      }
    });

    return {
      correct,
      wrong,
      skipped,
      total: state.questions.length,
      percentage: Math.round((correct / state.questions.length) * 100)
    };
  },

  getTopicQuestionCount: (subject, topic) => {
    const questions = getQuestionsByTopic(subject, topic);
    return questions.length;
  },

  getAvailablePapers: () => {
    return getAvailableTestPapers();
  },

  getQuestionCountInfo: () => {
    return getQuestionCounts();
  }
}));
